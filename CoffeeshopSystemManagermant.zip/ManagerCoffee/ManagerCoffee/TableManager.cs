﻿using ManagerCoffee.DAO;
using ManagerCoffee.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Menu = ManagerCoffee.DTO.Menu;

namespace ManagerCoffee
{
    public partial class TableManager : Form
    {


        public TableManager()
        {
            InitializeComponent();

            LoadTable();
            LoadCategory();
        }

        #region Method
        void LoadCategory() {
            List<Category> listCategory = CategoryDAO.Instance.GetListCategory();
            cbCategory.DataSource = listCategory;
            cbCategory.DisplayMember = "Name";
        }
        void LoadDrinkListByCategoryID(int id) {
            List<Drink> listDrink = DrinkDAO.Instance.GetDrinkByCategoryID(id);
            cbDrink.DataSource = listDrink;
            cbDrink.DisplayMember = "Name";
        }
        // load danh sach table
        void LoadTable() {
            List<Table> tableList = TableDAO.Instance.LoadTableList();

            foreach (Table item in tableList) {
                Button btn = new Button() { Width = TableDAO.TableWidth, Height = TableDAO.TableHeight };
                btn.Text = item.Name + Environment.NewLine + item.Status;
                btn.Click += btn_Click;
                btn.Tag = item;

                switch (item.Status) {
                    case "empty":
                        btn.BackColor = Color.LightGray;
                        break;
                    default:
                        btn.BackColor = Color.Red;
                        break;
                }
                flpTable.Controls.Add(btn);
            }
        }
        void ShowBill(int id) {
            listView1.Items.Clear();
            List<Menu> listBillList = MenuDAO.Instance.GetListMenuByTable(id);
            float totalPrice = 0;

            foreach (Menu item in listBillList) {
                ListViewItem lvItem = new ListViewItem(item.DisplayName.ToString());
                lvItem.SubItems.Add(item.Count.ToString());
                lvItem.SubItems.Add(item.Price.ToString());
                lvItem.SubItems.Add(item.TotalPrice.ToString());
                totalPrice += item.TotalPrice;
                listView1.Items.Add(lvItem);
                
                
            }
            CultureInfo culture = new CultureInfo("vi-VN");

            Thread.CurrentThread.CurrentCulture = culture;
            txtbTotalPrice.Text = totalPrice.ToString("c");
        }

        #endregion


        #region Events
        void btn_Click(object sender, EventArgs e)
        {
            int tableID = ((sender as Button).Tag as Table).ID;
            listView1.Tag = (sender as Button).Tag;
            ShowBill(tableID);

        }
        private void TableManager_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AccountProfile a = new AccountProfile();
            a.ShowDialog();

        }

        private void thôngTinTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Admin a = new Admin();
            a.ShowDialog();
        }
        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = 0;

            ComboBox cb = sender as ComboBox;

            if (cb.SelectedItem == null)
                return;

            Category selected = cb.SelectedItem as Category;
            id = selected.ID;

            LoadDrinkListByCategoryID(id);
        }
      

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddDrink_Click(object sender, EventArgs e)
        {
            Table table = listView1.Tag as Table;

            int idBill = BillDAO.Instance.GetUncheckBillIDByTableID(table.ID);
            int drinkID = (cbDrink.SelectedItem as Drink).ID;
            int count = (int)nmDrinkCount.Value;
            if (idBill == -1)
            {
                BillDAO.Instance.InsertBill(table.ID);
                BillListDAO.Instance.InsertBillList(BillDAO.Instance.GetMaxIDBill(), drinkID, count);
            }
            // bill da ton tai
            else {
                BillListDAO.Instance.InsertBillList(idBill, drinkID, count);
            }

            // Load lai Menu
            ShowBill(table.ID);
        }
        

        #endregion
    }
}
