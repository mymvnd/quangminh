﻿namespace ManagerCoffee
{
    internal class ListViewBill
    {
        private object i;

        public ListViewBill(object i)
        {
            this.i = i;
        }
    }
}