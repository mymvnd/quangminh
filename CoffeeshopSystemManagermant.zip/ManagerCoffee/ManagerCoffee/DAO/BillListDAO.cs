﻿using ManagerCoffee.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerCoffee.DAO
{
    public class BillListDAO
    {
        private static BillListDAO instance;

        public static BillListDAO Instance {
            get { if (instance == null) instance = new BillListDAO(); return BillListDAO.instance; }
            private set { BillListDAO.instance = value; }
        }

        private BillListDAO() { }

        public List<BillList> GetListsBillList(int id) {
            List<BillList> listBillList = new List<BillList>();

            DataTable data = DataProvider.Instance.ExecuteQuery("SELECT * FROM dbo.BillList WHERE idBill = " + id );

            foreach (DataRow item in data.Rows) {
                BillList list = new BillList(item);
                listBillList.Add(list);
            }

            return listBillList;
        }
        public void InsertBillList(int idBill, int idDrink, int count)
        {
            DataProvider.Instance.ExecuteQuery("exec USP_InsertBillList @idBill , @idDrink , @count ", new object[] { idBill, idDrink, count });
        }
    }
}
