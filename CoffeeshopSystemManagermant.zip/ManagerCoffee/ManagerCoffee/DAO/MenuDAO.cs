﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManagerCoffee.DAO
{
    public class MenuDAO
    {
        private static MenuDAO instance;

        public static MenuDAO Instance
        {
            get { if (instance == null) instance = new MenuDAO(); return MenuDAO.instance; }
            private set { MenuDAO.instance = value; }
        }

        private MenuDAO() { }

        public List<ManagerCoffee.DTO.Menu> GetListMenuByTable(int id) {
            List<ManagerCoffee.DTO.Menu> listMenu = new List<ManagerCoffee.DTO.Menu>();

            string query = "SELECT D.DisplayName,BL.count, D.price, D.price* BL.count AS totalPrice FROM dbo.BillList AS BL, dbo.Bill AS B, dbo.Drink AS D WHERE BL.idBill = B.id AND BL.idDrink = D.id AND B.status = 0 AND B.idTable = " +id ;
            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows) {
                ManagerCoffee.DTO.Menu menu = new ManagerCoffee.DTO.Menu(item);
                listMenu.Add(menu);
            }

            return listMenu;
        }
    }
}
