﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerCoffee.DTO
{
    public class Drink
    {
        public Drink(int id, string name, int idMenu, float price)
        {
            this.ID = id;
            this.Name = name;
            this.IDMenu = idMenu;
            this.Price = price;
        }

        public Drink(DataRow row)
        {
            this.ID = (int)row["id"];
            this.Name = row["DisplayName"].ToString();
            this.iDMenu = (int)row["idMenu"];
            this.Price = (float)Convert.ToDouble(row["price"].ToString());
        }


        private int iD;

        public int ID { get { return iD; } set { iD = value; } }

        public string Name { get { return name; } set { name = value; } }

        public int IDMenu { get { return iDMenu; } set { iDMenu = value; } }

        public float Price { get { return price; } set { price = value; } }

        private string name;

        private int iDMenu;

        private float price;
    }
}
