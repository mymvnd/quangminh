﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerCoffee.DTO
{
    public class BillList
    {
        public BillList(int id, int idDrink, int idBill, int count) {
            this.ID = id;
            this.IDBill = idBill;
            this.IDDrink = idDrink;
            this.Count = count;
        }

        public BillList(DataRow row) {
            this.ID = (int)row["id"];
            this.IDBill = (int)row["idBill"];
            this.IDDrink = (int)row["idDrink"];
            this.Count = (int)row["count"];
        }

        private int count;
        private int iDDrink;
        private int iDBill;
        private int iD;

        public int Count {
            get { return count; }
            set { count = value; }
        }

        public int IDDrink {
            get { return iDDrink; }
            set { iDDrink = value; }
        }

        public int ID {
            get { return iD; }
            set { iD = value; }
        }

        public int IDBill {
            get { return iDBill; }
            set { iDBill = value; } 
        }
    }
}
