﻿namespace ManagerCoffee
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tpAccount = new System.Windows.Forms.TabPage();
            this.panel33 = new System.Windows.Forms.Panel();
            this.btnSeeAccount = new System.Windows.Forms.Button();
            this.btnFixAccount = new System.Windows.Forms.Button();
            this.btnDeleteAccount = new System.Windows.Forms.Button();
            this.btnAddAccount = new System.Windows.Forms.Button();
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnResetPass = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.cbAccountType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.txtbDisplayAccount = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.txtUserNameAccount = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txtbAccountID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.dtgvAccount = new System.Windows.Forms.DataGridView();
            this.tpTable = new System.Windows.Forms.TabPage();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.cbTableCond = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txtbTableName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txtbTableID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btnSeeTable = new System.Windows.Forms.Button();
            this.btnFixTable = new System.Windows.Forms.Button();
            this.btnDeleteTable = new System.Windows.Forms.Button();
            this.btnAddTable = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dtgvTable = new System.Windows.Forms.DataGridView();
            this.tpDrinkCategory = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtbMenuName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtbCategoryID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.dtgvCategory = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnSeeCategory = new System.Windows.Forms.Button();
            this.btnFixCategory = new System.Windows.Forms.Button();
            this.btnDeleteCategory = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.tpDrink = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtbSearchDrinkName = new System.Windows.Forms.TextBox();
            this.btnSearchDrink = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.nmDrinkPrice = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.cbDrinkDirect = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtbDrinkName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtbDrinkID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSeeDrink = new System.Windows.Forms.Button();
            this.btnFixDrink = new System.Windows.Forms.Button();
            this.btnDeleteDrink = new System.Windows.Forms.Button();
            this.btnAddDrink = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtgvDrink = new System.Windows.Forms.DataGridView();
            this.tpBill = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnViewBill = new System.Windows.Forms.Button();
            this.dtpkToDate = new System.Windows.Forms.DateTimePicker();
            this.dtpkFromDate = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgvBill = new System.Windows.Forms.DataGridView();
            this.tcAdmin = new System.Windows.Forms.TabControl();
            this.tpAccount.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAccount)).BeginInit();
            this.tpTable.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTable)).BeginInit();
            this.tpDrinkCategory.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvCategory)).BeginInit();
            this.panel11.SuspendLayout();
            this.tpDrink.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmDrinkPrice)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDrink)).BeginInit();
            this.tpBill.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).BeginInit();
            this.tcAdmin.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpAccount
            // 
            this.tpAccount.Controls.Add(this.panel33);
            this.tpAccount.Controls.Add(this.panel28);
            this.tpAccount.Controls.Add(this.panel27);
            this.tpAccount.Location = new System.Drawing.Point(4, 29);
            this.tpAccount.Name = "tpAccount";
            this.tpAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tpAccount.Size = new System.Drawing.Size(946, 508);
            this.tpAccount.TabIndex = 4;
            this.tpAccount.Text = "Account";
            this.tpAccount.UseVisualStyleBackColor = true;
            this.tpAccount.Click += new System.EventHandler(this.tpAccount_Click);
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.btnSeeAccount);
            this.panel33.Controls.Add(this.btnFixAccount);
            this.panel33.Controls.Add(this.btnDeleteAccount);
            this.panel33.Controls.Add(this.btnAddAccount);
            this.panel33.Location = new System.Drawing.Point(10, 6);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(535, 91);
            this.panel33.TabIndex = 4;
            // 
            // btnSeeAccount
            // 
            this.btnSeeAccount.Location = new System.Drawing.Point(423, 3);
            this.btnSeeAccount.Name = "btnSeeAccount";
            this.btnSeeAccount.Size = new System.Drawing.Size(109, 85);
            this.btnSeeAccount.TabIndex = 3;
            this.btnSeeAccount.Text = "See";
            this.btnSeeAccount.UseVisualStyleBackColor = true;
            // 
            // btnFixAccount
            // 
            this.btnFixAccount.Location = new System.Drawing.Point(281, 3);
            this.btnFixAccount.Name = "btnFixAccount";
            this.btnFixAccount.Size = new System.Drawing.Size(109, 85);
            this.btnFixAccount.TabIndex = 2;
            this.btnFixAccount.Text = "Fix";
            this.btnFixAccount.UseVisualStyleBackColor = true;
            // 
            // btnDeleteAccount
            // 
            this.btnDeleteAccount.Location = new System.Drawing.Point(148, 3);
            this.btnDeleteAccount.Name = "btnDeleteAccount";
            this.btnDeleteAccount.Size = new System.Drawing.Size(109, 85);
            this.btnDeleteAccount.TabIndex = 1;
            this.btnDeleteAccount.Text = "Delete";
            this.btnDeleteAccount.UseVisualStyleBackColor = true;
            // 
            // btnAddAccount
            // 
            this.btnAddAccount.Location = new System.Drawing.Point(4, 3);
            this.btnAddAccount.Name = "btnAddAccount";
            this.btnAddAccount.Size = new System.Drawing.Size(109, 85);
            this.btnAddAccount.TabIndex = 0;
            this.btnAddAccount.Text = "Add";
            this.btnAddAccount.UseVisualStyleBackColor = true;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnResetPass);
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Controls.Add(this.panel30);
            this.panel28.Controls.Add(this.panel31);
            this.panel28.Controls.Add(this.panel32);
            this.panel28.Location = new System.Drawing.Point(567, 115);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(373, 387);
            this.panel28.TabIndex = 3;
            // 
            // btnResetPass
            // 
            this.btnResetPass.Location = new System.Drawing.Point(196, 259);
            this.btnResetPass.Name = "btnResetPass";
            this.btnResetPass.Size = new System.Drawing.Size(174, 85);
            this.btnResetPass.TabIndex = 4;
            this.btnResetPass.Text = "Re - Password";
            this.btnResetPass.UseVisualStyleBackColor = true;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.cbAccountType);
            this.panel29.Controls.Add(this.label12);
            this.panel29.Location = new System.Drawing.Point(6, 199);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(364, 54);
            this.panel29.TabIndex = 4;
            // 
            // cbAccountType
            // 
            this.cbAccountType.FormattingEnabled = true;
            this.cbAccountType.Location = new System.Drawing.Point(154, 8);
            this.cbAccountType.Name = "cbAccountType";
            this.cbAccountType.Size = new System.Drawing.Size(192, 28);
            this.cbAccountType.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 29);
            this.label12.TabIndex = 1;
            this.label12.Text = "Type:";
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.txtbDisplayAccount);
            this.panel30.Controls.Add(this.label13);
            this.panel30.Location = new System.Drawing.Point(6, 139);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(364, 54);
            this.panel30.TabIndex = 3;
            // 
            // txtbDisplayAccount
            // 
            this.txtbDisplayAccount.Location = new System.Drawing.Point(154, 12);
            this.txtbDisplayAccount.Name = "txtbDisplayAccount";
            this.txtbDisplayAccount.Size = new System.Drawing.Size(192, 26);
            this.txtbDisplayAccount.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 29);
            this.label13.TabIndex = 1;
            this.label13.Text = "Disp Name:";
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.txtUserNameAccount);
            this.panel31.Controls.Add(this.label14);
            this.panel31.Location = new System.Drawing.Point(6, 79);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(364, 54);
            this.panel31.TabIndex = 2;
            // 
            // txtUserNameAccount
            // 
            this.txtUserNameAccount.Location = new System.Drawing.Point(154, 11);
            this.txtUserNameAccount.Name = "txtUserNameAccount";
            this.txtUserNameAccount.Size = new System.Drawing.Size(192, 26);
            this.txtUserNameAccount.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 29);
            this.label14.TabIndex = 1;
            this.label14.Text = "User Name:";
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txtbAccountID);
            this.panel32.Controls.Add(this.label15);
            this.panel32.Location = new System.Drawing.Point(6, 19);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(364, 54);
            this.panel32.TabIndex = 1;
            // 
            // txtbAccountID
            // 
            this.txtbAccountID.Location = new System.Drawing.Point(154, 11);
            this.txtbAccountID.Name = "txtbAccountID";
            this.txtbAccountID.ReadOnly = true;
            this.txtbAccountID.Size = new System.Drawing.Size(192, 26);
            this.txtbAccountID.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 29);
            this.label15.TabIndex = 1;
            this.label15.Text = "ID:";
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.dtgvAccount);
            this.panel27.Location = new System.Drawing.Point(6, 115);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(535, 387);
            this.panel27.TabIndex = 1;
            // 
            // dtgvAccount
            // 
            this.dtgvAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvAccount.Location = new System.Drawing.Point(4, 4);
            this.dtgvAccount.Name = "dtgvAccount";
            this.dtgvAccount.RowHeadersWidth = 62;
            this.dtgvAccount.RowTemplate.Height = 28;
            this.dtgvAccount.Size = new System.Drawing.Size(528, 380);
            this.dtgvAccount.TabIndex = 0;
            this.dtgvAccount.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvAccount_CellContentClick);
            // 
            // tpTable
            // 
            this.tpTable.Controls.Add(this.panel23);
            this.tpTable.Controls.Add(this.panel22);
            this.tpTable.Controls.Add(this.panel14);
            this.tpTable.Location = new System.Drawing.Point(4, 29);
            this.tpTable.Name = "tpTable";
            this.tpTable.Padding = new System.Windows.Forms.Padding(3);
            this.tpTable.Size = new System.Drawing.Size(946, 508);
            this.tpTable.TabIndex = 3;
            this.tpTable.Text = "Table";
            this.tpTable.UseVisualStyleBackColor = true;
            this.tpTable.Click += new System.EventHandler(this.tpTable_Click);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.panel26);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Controls.Add(this.panel25);
            this.panel23.Location = new System.Drawing.Point(567, 112);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(373, 387);
            this.panel23.TabIndex = 6;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.cbTableCond);
            this.panel26.Controls.Add(this.label11);
            this.panel26.Location = new System.Drawing.Point(6, 139);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(364, 54);
            this.panel26.TabIndex = 3;
            // 
            // cbTableCond
            // 
            this.cbTableCond.FormattingEnabled = true;
            this.cbTableCond.Location = new System.Drawing.Point(154, 8);
            this.cbTableCond.Name = "cbTableCond";
            this.cbTableCond.Size = new System.Drawing.Size(192, 28);
            this.cbTableCond.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 29);
            this.label11.TabIndex = 1;
            this.label11.Text = "Condition:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txtbTableName);
            this.panel24.Controls.Add(this.label9);
            this.panel24.Location = new System.Drawing.Point(6, 79);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(364, 54);
            this.panel24.TabIndex = 2;
            // 
            // txtbTableName
            // 
            this.txtbTableName.Location = new System.Drawing.Point(154, 11);
            this.txtbTableName.Name = "txtbTableName";
            this.txtbTableName.Size = new System.Drawing.Size(192, 26);
            this.txtbTableName.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 29);
            this.label9.TabIndex = 1;
            this.label9.Text = "Table Name:";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.txtbTableID);
            this.panel25.Controls.Add(this.label10);
            this.panel25.Location = new System.Drawing.Point(6, 19);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(364, 54);
            this.panel25.TabIndex = 1;
            // 
            // txtbTableID
            // 
            this.txtbTableID.Location = new System.Drawing.Point(154, 11);
            this.txtbTableID.Name = "txtbTableID";
            this.txtbTableID.ReadOnly = true;
            this.txtbTableID.Size = new System.Drawing.Size(192, 26);
            this.txtbTableID.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 29);
            this.label10.TabIndex = 1;
            this.label10.Text = "ID:";
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btnSeeTable);
            this.panel22.Controls.Add(this.btnFixTable);
            this.panel22.Controls.Add(this.btnDeleteTable);
            this.panel22.Controls.Add(this.btnAddTable);
            this.panel22.Location = new System.Drawing.Point(10, 6);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(535, 91);
            this.panel22.TabIndex = 5;
            // 
            // btnSeeTable
            // 
            this.btnSeeTable.Location = new System.Drawing.Point(423, 3);
            this.btnSeeTable.Name = "btnSeeTable";
            this.btnSeeTable.Size = new System.Drawing.Size(109, 85);
            this.btnSeeTable.TabIndex = 3;
            this.btnSeeTable.Text = "See";
            this.btnSeeTable.UseVisualStyleBackColor = true;
            // 
            // btnFixTable
            // 
            this.btnFixTable.Location = new System.Drawing.Point(281, 3);
            this.btnFixTable.Name = "btnFixTable";
            this.btnFixTable.Size = new System.Drawing.Size(109, 85);
            this.btnFixTable.TabIndex = 2;
            this.btnFixTable.Text = "Fix";
            this.btnFixTable.UseVisualStyleBackColor = true;
            // 
            // btnDeleteTable
            // 
            this.btnDeleteTable.Location = new System.Drawing.Point(148, 3);
            this.btnDeleteTable.Name = "btnDeleteTable";
            this.btnDeleteTable.Size = new System.Drawing.Size(109, 85);
            this.btnDeleteTable.TabIndex = 1;
            this.btnDeleteTable.Text = "Delete";
            this.btnDeleteTable.UseVisualStyleBackColor = true;
            // 
            // btnAddTable
            // 
            this.btnAddTable.Location = new System.Drawing.Point(4, 3);
            this.btnAddTable.Name = "btnAddTable";
            this.btnAddTable.Size = new System.Drawing.Size(109, 85);
            this.btnAddTable.TabIndex = 0;
            this.btnAddTable.Text = "Add";
            this.btnAddTable.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dtgvTable);
            this.panel14.Location = new System.Drawing.Point(6, 112);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(535, 390);
            this.panel14.TabIndex = 4;
            // 
            // dtgvTable
            // 
            this.dtgvTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvTable.Location = new System.Drawing.Point(4, 3);
            this.dtgvTable.Name = "dtgvTable";
            this.dtgvTable.RowHeadersWidth = 62;
            this.dtgvTable.RowTemplate.Height = 28;
            this.dtgvTable.Size = new System.Drawing.Size(535, 381);
            this.dtgvTable.TabIndex = 0;
            // 
            // tpDrinkCategory
            // 
            this.tpDrinkCategory.Controls.Add(this.panel13);
            this.tpDrinkCategory.Controls.Add(this.panel12);
            this.tpDrinkCategory.Controls.Add(this.panel11);
            this.tpDrinkCategory.Location = new System.Drawing.Point(4, 29);
            this.tpDrinkCategory.Name = "tpDrinkCategory";
            this.tpDrinkCategory.Padding = new System.Windows.Forms.Padding(3);
            this.tpDrinkCategory.Size = new System.Drawing.Size(946, 508);
            this.tpDrinkCategory.TabIndex = 2;
            this.tpDrinkCategory.Text = "Menu";
            this.tpDrinkCategory.UseVisualStyleBackColor = true;
            this.tpDrinkCategory.Click += new System.EventHandler(this.tpDrinkCategory_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel16);
            this.panel13.Controls.Add(this.panel17);
            this.panel13.Location = new System.Drawing.Point(567, 106);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(373, 387);
            this.panel13.TabIndex = 4;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txtbMenuName);
            this.panel16.Controls.Add(this.label7);
            this.panel16.Location = new System.Drawing.Point(6, 79);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(364, 54);
            this.panel16.TabIndex = 2;
            // 
            // txtbMenuName
            // 
            this.txtbMenuName.Location = new System.Drawing.Point(154, 11);
            this.txtbMenuName.Name = "txtbMenuName";
            this.txtbMenuName.Size = new System.Drawing.Size(192, 26);
            this.txtbMenuName.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 29);
            this.label7.TabIndex = 1;
            this.label7.Text = "Menu Name:";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txtbCategoryID);
            this.panel17.Controls.Add(this.label8);
            this.panel17.Location = new System.Drawing.Point(6, 19);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(364, 54);
            this.panel17.TabIndex = 1;
            // 
            // txtbCategoryID
            // 
            this.txtbCategoryID.Location = new System.Drawing.Point(154, 11);
            this.txtbCategoryID.Name = "txtbCategoryID";
            this.txtbCategoryID.ReadOnly = true;
            this.txtbCategoryID.Size = new System.Drawing.Size(192, 26);
            this.txtbCategoryID.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 29);
            this.label8.TabIndex = 1;
            this.label8.Text = "ID:";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.dtgvCategory);
            this.panel12.Location = new System.Drawing.Point(6, 103);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(535, 390);
            this.panel12.TabIndex = 3;
            // 
            // dtgvCategory
            // 
            this.dtgvCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvCategory.Location = new System.Drawing.Point(4, 3);
            this.dtgvCategory.Name = "dtgvCategory";
            this.dtgvCategory.RowHeadersWidth = 62;
            this.dtgvCategory.RowTemplate.Height = 28;
            this.dtgvCategory.Size = new System.Drawing.Size(528, 381);
            this.dtgvCategory.TabIndex = 0;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btnSeeCategory);
            this.panel11.Controls.Add(this.btnFixCategory);
            this.panel11.Controls.Add(this.btnDeleteCategory);
            this.panel11.Controls.Add(this.btnAddCategory);
            this.panel11.Location = new System.Drawing.Point(6, 6);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(535, 91);
            this.panel11.TabIndex = 2;
            // 
            // btnSeeCategory
            // 
            this.btnSeeCategory.Location = new System.Drawing.Point(423, 3);
            this.btnSeeCategory.Name = "btnSeeCategory";
            this.btnSeeCategory.Size = new System.Drawing.Size(109, 85);
            this.btnSeeCategory.TabIndex = 3;
            this.btnSeeCategory.Text = "See";
            this.btnSeeCategory.UseVisualStyleBackColor = true;
            // 
            // btnFixCategory
            // 
            this.btnFixCategory.Location = new System.Drawing.Point(281, 3);
            this.btnFixCategory.Name = "btnFixCategory";
            this.btnFixCategory.Size = new System.Drawing.Size(109, 85);
            this.btnFixCategory.TabIndex = 2;
            this.btnFixCategory.Text = "Fix";
            this.btnFixCategory.UseVisualStyleBackColor = true;
            // 
            // btnDeleteCategory
            // 
            this.btnDeleteCategory.Location = new System.Drawing.Point(148, 3);
            this.btnDeleteCategory.Name = "btnDeleteCategory";
            this.btnDeleteCategory.Size = new System.Drawing.Size(109, 85);
            this.btnDeleteCategory.TabIndex = 1;
            this.btnDeleteCategory.Text = "Delete";
            this.btnDeleteCategory.UseVisualStyleBackColor = true;
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Location = new System.Drawing.Point(4, 3);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(109, 85);
            this.btnAddCategory.TabIndex = 0;
            this.btnAddCategory.Text = "Add Drink";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            // 
            // tpDrink
            // 
            this.tpDrink.Controls.Add(this.panel6);
            this.tpDrink.Controls.Add(this.panel5);
            this.tpDrink.Controls.Add(this.panel4);
            this.tpDrink.Controls.Add(this.panel3);
            this.tpDrink.Location = new System.Drawing.Point(4, 29);
            this.tpDrink.Name = "tpDrink";
            this.tpDrink.Padding = new System.Windows.Forms.Padding(3);
            this.tpDrink.Size = new System.Drawing.Size(946, 508);
            this.tpDrink.TabIndex = 1;
            this.tpDrink.Text = "Drink";
            this.tpDrink.UseVisualStyleBackColor = true;
            this.tpDrink.Click += new System.EventHandler(this.tpDrink_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtbSearchDrinkName);
            this.panel6.Controls.Add(this.btnSearchDrink);
            this.panel6.Location = new System.Drawing.Point(560, 6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(370, 91);
            this.panel6.TabIndex = 3;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // txtbSearchDrinkName
            // 
            this.txtbSearchDrinkName.Location = new System.Drawing.Point(3, 37);
            this.txtbSearchDrinkName.Name = "txtbSearchDrinkName";
            this.txtbSearchDrinkName.Size = new System.Drawing.Size(235, 26);
            this.txtbSearchDrinkName.TabIndex = 5;
            this.txtbSearchDrinkName.TextChanged += new System.EventHandler(this.txtbSearchDrinkName_TextChanged);
            // 
            // btnSearchDrink
            // 
            this.btnSearchDrink.Location = new System.Drawing.Point(244, 3);
            this.btnSearchDrink.Name = "btnSearchDrink";
            this.btnSearchDrink.Size = new System.Drawing.Size(123, 85);
            this.btnSearchDrink.TabIndex = 4;
            this.btnSearchDrink.Text = "SearchDrink";
            this.btnSearchDrink.UseVisualStyleBackColor = true;
            this.btnSearchDrink.Click += new System.EventHandler(this.btnSearchDrink_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(557, 103);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(373, 387);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.nmDrinkPrice);
            this.panel10.Controls.Add(this.label4);
            this.panel10.Location = new System.Drawing.Point(6, 199);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(364, 54);
            this.panel10.TabIndex = 3;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // nmDrinkPrice
            // 
            this.nmDrinkPrice.Location = new System.Drawing.Point(154, 13);
            this.nmDrinkPrice.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.nmDrinkPrice.Name = "nmDrinkPrice";
            this.nmDrinkPrice.Size = new System.Drawing.Size(192, 26);
            this.nmDrinkPrice.TabIndex = 4;
            this.nmDrinkPrice.ValueChanged += new System.EventHandler(this.nmDrinkPrice_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 29);
            this.label4.TabIndex = 1;
            this.label4.Text = "Price:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.cbDrinkDirect);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Location = new System.Drawing.Point(6, 139);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(364, 54);
            this.panel9.TabIndex = 3;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // cbDrinkDirect
            // 
            this.cbDrinkDirect.FormattingEnabled = true;
            this.cbDrinkDirect.Location = new System.Drawing.Point(154, 8);
            this.cbDrinkDirect.Name = "cbDrinkDirect";
            this.cbDrinkDirect.Size = new System.Drawing.Size(192, 28);
            this.cbDrinkDirect.TabIndex = 2;
            this.cbDrinkDirect.SelectedIndexChanged += new System.EventHandler(this.cbDrinkDirect_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 29);
            this.label3.TabIndex = 1;
            this.label3.Text = "Directory:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtbDrinkName);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Location = new System.Drawing.Point(6, 79);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(364, 54);
            this.panel8.TabIndex = 2;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // txtbDrinkName
            // 
            this.txtbDrinkName.Location = new System.Drawing.Point(154, 11);
            this.txtbDrinkName.Name = "txtbDrinkName";
            this.txtbDrinkName.Size = new System.Drawing.Size(192, 26);
            this.txtbDrinkName.TabIndex = 1;
            this.txtbDrinkName.TextChanged += new System.EventHandler(this.txtbDrinkName_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Drink Name:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtbDrinkID);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Location = new System.Drawing.Point(6, 19);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(364, 54);
            this.panel7.TabIndex = 1;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // txtbDrinkID
            // 
            this.txtbDrinkID.Location = new System.Drawing.Point(154, 11);
            this.txtbDrinkID.Name = "txtbDrinkID";
            this.txtbDrinkID.ReadOnly = true;
            this.txtbDrinkID.Size = new System.Drawing.Size(192, 26);
            this.txtbDrinkID.TabIndex = 1;
            this.txtbDrinkID.TextChanged += new System.EventHandler(this.txtbDrinkID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnSeeDrink);
            this.panel4.Controls.Add(this.btnFixDrink);
            this.panel4.Controls.Add(this.btnDeleteDrink);
            this.panel4.Controls.Add(this.btnAddDrink);
            this.panel4.Location = new System.Drawing.Point(16, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(535, 91);
            this.panel4.TabIndex = 1;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // btnSeeDrink
            // 
            this.btnSeeDrink.Location = new System.Drawing.Point(423, 3);
            this.btnSeeDrink.Name = "btnSeeDrink";
            this.btnSeeDrink.Size = new System.Drawing.Size(109, 85);
            this.btnSeeDrink.TabIndex = 3;
            this.btnSeeDrink.Text = "See";
            this.btnSeeDrink.UseVisualStyleBackColor = true;
            this.btnSeeDrink.Click += new System.EventHandler(this.btnSeeDrink_Click);
            // 
            // btnFixDrink
            // 
            this.btnFixDrink.Location = new System.Drawing.Point(281, 3);
            this.btnFixDrink.Name = "btnFixDrink";
            this.btnFixDrink.Size = new System.Drawing.Size(109, 85);
            this.btnFixDrink.TabIndex = 2;
            this.btnFixDrink.Text = "Fix";
            this.btnFixDrink.UseVisualStyleBackColor = true;
            this.btnFixDrink.Click += new System.EventHandler(this.btnFixDrink_Click);
            // 
            // btnDeleteDrink
            // 
            this.btnDeleteDrink.Location = new System.Drawing.Point(148, 3);
            this.btnDeleteDrink.Name = "btnDeleteDrink";
            this.btnDeleteDrink.Size = new System.Drawing.Size(109, 85);
            this.btnDeleteDrink.TabIndex = 1;
            this.btnDeleteDrink.Text = "Delete";
            this.btnDeleteDrink.UseVisualStyleBackColor = true;
            this.btnDeleteDrink.Click += new System.EventHandler(this.btnDeleteDrink_Click);
            // 
            // btnAddDrink
            // 
            this.btnAddDrink.Location = new System.Drawing.Point(4, 3);
            this.btnAddDrink.Name = "btnAddDrink";
            this.btnAddDrink.Size = new System.Drawing.Size(109, 85);
            this.btnAddDrink.TabIndex = 0;
            this.btnAddDrink.Text = "Add Drink";
            this.btnAddDrink.UseVisualStyleBackColor = true;
            this.btnAddDrink.Click += new System.EventHandler(this.btnAddDrink_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtgvDrink);
            this.panel3.Location = new System.Drawing.Point(16, 103);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(535, 387);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // dtgvDrink
            // 
            this.dtgvDrink.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDrink.Location = new System.Drawing.Point(4, 4);
            this.dtgvDrink.Name = "dtgvDrink";
            this.dtgvDrink.RowHeadersWidth = 62;
            this.dtgvDrink.RowTemplate.Height = 28;
            this.dtgvDrink.Size = new System.Drawing.Size(528, 380);
            this.dtgvDrink.TabIndex = 0;
            this.dtgvDrink.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvDrink_CellContentClick);
            // 
            // tpBill
            // 
            this.tpBill.Controls.Add(this.panel2);
            this.tpBill.Controls.Add(this.panel1);
            this.tpBill.Location = new System.Drawing.Point(4, 29);
            this.tpBill.Name = "tpBill";
            this.tpBill.Padding = new System.Windows.Forms.Padding(3);
            this.tpBill.Size = new System.Drawing.Size(946, 508);
            this.tpBill.TabIndex = 0;
            this.tpBill.Text = "Revenue";
            this.tpBill.UseVisualStyleBackColor = true;
            this.tpBill.Click += new System.EventHandler(this.tpBill_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnViewBill);
            this.panel2.Controls.Add(this.dtpkToDate);
            this.panel2.Controls.Add(this.dtpkFromDate);
            this.panel2.Location = new System.Drawing.Point(9, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(931, 43);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnViewBill
            // 
            this.btnViewBill.Location = new System.Drawing.Point(438, 6);
            this.btnViewBill.Name = "btnViewBill";
            this.btnViewBill.Size = new System.Drawing.Size(74, 34);
            this.btnViewBill.TabIndex = 2;
            this.btnViewBill.Text = "Statistical";
            this.btnViewBill.UseVisualStyleBackColor = true;
            this.btnViewBill.Click += new System.EventHandler(this.btnViewBill_Click);
            // 
            // dtpkToDate
            // 
            this.dtpkToDate.Location = new System.Drawing.Point(622, 8);
            this.dtpkToDate.Name = "dtpkToDate";
            this.dtpkToDate.Size = new System.Drawing.Size(306, 26);
            this.dtpkToDate.TabIndex = 1;
            this.dtpkToDate.ValueChanged += new System.EventHandler(this.dtpkToDate_ValueChanged);
            // 
            // dtpkFromDate
            // 
            this.dtpkFromDate.Location = new System.Drawing.Point(3, 8);
            this.dtpkFromDate.Name = "dtpkFromDate";
            this.dtpkFromDate.Size = new System.Drawing.Size(333, 26);
            this.dtpkFromDate.TabIndex = 0;
            this.dtpkFromDate.ValueChanged += new System.EventHandler(this.dtpkFromDate_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtgvBill);
            this.panel1.Location = new System.Drawing.Point(6, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(934, 432);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dtgvBill
            // 
            this.dtgvBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBill.Location = new System.Drawing.Point(3, 3);
            this.dtgvBill.Name = "dtgvBill";
            this.dtgvBill.RowHeadersWidth = 62;
            this.dtgvBill.RowTemplate.Height = 28;
            this.dtgvBill.Size = new System.Drawing.Size(928, 422);
            this.dtgvBill.TabIndex = 0;
            this.dtgvBill.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvBill_CellContentClick);
            // 
            // tcAdmin
            // 
            this.tcAdmin.Controls.Add(this.tpBill);
            this.tcAdmin.Controls.Add(this.tpDrink);
            this.tcAdmin.Controls.Add(this.tpDrinkCategory);
            this.tcAdmin.Controls.Add(this.tpTable);
            this.tcAdmin.Controls.Add(this.tpAccount);
            this.tcAdmin.Location = new System.Drawing.Point(11, 14);
            this.tcAdmin.Name = "tcAdmin";
            this.tcAdmin.SelectedIndex = 0;
            this.tcAdmin.Size = new System.Drawing.Size(954, 541);
            this.tcAdmin.TabIndex = 0;
            this.tcAdmin.SelectedIndexChanged += new System.EventHandler(this.tcAdmin_SelectedIndexChanged);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 565);
            this.Controls.Add(this.tcAdmin);
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.tpAccount.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAccount)).EndInit();
            this.tpTable.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTable)).EndInit();
            this.tpDrinkCategory.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvCategory)).EndInit();
            this.panel11.ResumeLayout(false);
            this.tpDrink.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmDrinkPrice)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDrink)).EndInit();
            this.tpBill.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).EndInit();
            this.tcAdmin.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tpAccount;
        private System.Windows.Forms.TabPage tpTable;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txtbTableName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txtbTableID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btnSeeTable;
        private System.Windows.Forms.Button btnFixTable;
        private System.Windows.Forms.Button btnDeleteTable;
        private System.Windows.Forms.Button btnAddTable;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dtgvTable;
        private System.Windows.Forms.TabPage tpDrinkCategory;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtbMenuName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txtbCategoryID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.DataGridView dtgvCategory;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnSeeCategory;
        private System.Windows.Forms.Button btnFixCategory;
        private System.Windows.Forms.Button btnDeleteCategory;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.TabPage tpDrink;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtbSearchDrinkName;
        private System.Windows.Forms.Button btnSearchDrink;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.NumericUpDown nmDrinkPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cbDrinkDirect;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtbDrinkName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtbDrinkID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnSeeDrink;
        private System.Windows.Forms.Button btnFixDrink;
        private System.Windows.Forms.Button btnDeleteDrink;
        private System.Windows.Forms.Button btnAddDrink;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtgvDrink;
        private System.Windows.Forms.TabPage tpBill;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnViewBill;
        private System.Windows.Forms.DateTimePicker dtpkToDate;
        private System.Windows.Forms.DateTimePicker dtpkFromDate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dtgvBill;
        private System.Windows.Forms.TabControl tcAdmin;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.DataGridView dtgvAccount;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button btnSeeAccount;
        private System.Windows.Forms.Button btnFixAccount;
        private System.Windows.Forms.Button btnDeleteAccount;
        private System.Windows.Forms.Button btnAddAccount;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox txtUserNameAccount;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txtbAccountID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.ComboBox cbAccountType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtbDisplayAccount;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.ComboBox cbTableCond;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnResetPass;
    }
}