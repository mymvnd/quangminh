﻿CREATE DATABASE QuanLyQuanCafe



DROP DATABASE QuanLyQuanCafe

USE QuanLyQuanCafe
GO
--Food
--Drink
--Menu
--Account
--Table
--Bill
--BillList

CREATE TABLE Tablee
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(100)NOT NULL,
	status NVARCHAR(100) NOT NULL --NULL || NOTNULL

)
GO 

CREATE TABLE Account
(
	id INT IDENTITY	PRIMARY KEY,
	DisplayName NVARCHAR(100) NOT NULL,
	UserName NVARCHAR(100) NOT NULL,
	PW NVARCHAR(100) NOT NULL,
	Type INT NOT NULL
)

GO

CREATE TABLE Menu
(
	id INT IDENTITY	PRIMARY KEY,
	DisplayName NVARCHAR(100) NOT NULL,

)
GO
CREATE TABLE Drink
(
	id INT IDENTITY	PRIMARY KEY,
	DisplayName NVARCHAR(100) NOT NULL,
	idMenu INT NOT NULL,
	price FLOAT NOT NULL DEFAULT 0,

	FOREIGN KEY (idMenu) REFERENCES dbo.Menu(id)
)
GO
CREATE TABLE Bill
(
	id INT IDENTITY	PRIMARY KEY,
	DateCheckIn DATETIME NOT NULL DEFAULT GETDATE(),
	DateCheckOut DATETIME,
	idTable INT NOT NULL,
	status INT NOT NULL DEFAULT 0,
	FOREIGN KEY (idTable) REFERENCES dbo.Tablee(id)
)
GO
CREATE TABLE BillList
(
	id INT IDENTITY	PRIMARY KEY,
	idBill INT NOT NULL,
	idDrink INT NOT NULL,
	count INT NOT NULL DEFAULT 0

	FOREIGN KEY (idBill) REFERENCES dbo.Bill(id),
	FOREIGN KEY (idDrink) REFERENCES dbo.Drink(id)
)
GO

/*Liên quan đến Account.*/

INSERT INTO dbo.Account
        ( DisplayName, UserName, PW, Type )
VALUES  ( N'Admin', -- DisplayName - nvarchar(100)
          N'Cheng56', -- UserName - nvarchar(100)
          N'1', -- PW - nvarchar(100)
          1  -- Type - int
        )

INSERT INTO dbo.Account
        ( DisplayName, UserName, PW, Type )
VALUES  ( N'Staff', -- DisplayName - nvarchar(100)
          N'Staff', -- UserName - nvarchar(100)
          N'1', -- PW - nvarchar(100)
          0  -- Type - int
        )
GO

INSERT INTO dbo.Account
        ( DisplayName, UserName, PW, Type )
VALUES  ( N'Admin', -- DisplayName - nvarchar(100)
          N'Minh', -- UserName - nvarchar(100)
          N'1', -- PW - nvarchar(100)
          2  -- Type - int
        )



CREATE PROC USP_GetAccountByUserName1
@userName nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE  UserName = @userName
END
GO

EXEC dbo.USP_GetAccountByUserName1 @userName = N'Cheng56' -- nvarchar(100)
GO

CREATE PROC USP_Login
@userName nvarchar(100), @password nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE UserName = @userName AND PW = @password
END
GO

CREATE PROC USP_GetAccountByUserName2
@userName nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE  UserName = @userName
END
GO

EXEC dbo.USP_GetAccountByUserName2 @userName = N'Minh' -- nvarchar(100)
GO

CREATE PROC USP_Login1
@userName nvarchar(100), @password nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE UserName = @userName AND PW = @password
END
GO

/*liên quan đến Table*/

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 1', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )
INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 2', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )
INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 3', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )
INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 4', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 5', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 6', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 7', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 8', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 9', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 10', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 11', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )

INSERT dbo.Tablee
        ( name, status )
VALUES  ( N'Table 12', -- name - nvarchar(100)
          N'empty'  -- status - nvarchar(100)
          )
SELECT * FROM dbo.Tablee
GO

CREATE PROC USP_GetTableList
AS SELECT * FROM dbo.Tablee
GO

UPDATE dbo.Tablee SET status = N'Position is been filled' WHERE id =2


EXEC dbo.USP_GetTableList
GO

/*Để hiển thị được hóa đơn cần thông qua build liên quan vs table và 
danh sách những đồ uống đó sẽ đc hiện thị trong BuillList */
/*Chúng ta phải chèn dữ liệu vào 2 bảng Build và BuildList*/

-- add menu
INSERT dbo.Menu
        ( DisplayName )
VALUES  ( N'Coffee'  -- DisplayName - nvarchar(100)
          )
INSERT dbo.Menu
        ( DisplayName )
VALUES  ( N'Trà Đá'  -- DisplayName - nvarchar(100)
          )
INSERT dbo.Menu
        ( DisplayName )
VALUES  ( N'JUICE'  -- DisplayName - nvarchar(100)
          )
INSERT dbo.Menu
        ( DisplayName )
VALUES  ( N'Milk Tea'  -- DisplayName - nvarchar(100)
          )
INSERT dbo.Menu
        ( DisplayName )
VALUES  ( N'Soft Drink'  -- DisplayName - nvarchar(100)
          )
/*Add Drink*/

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Capuchino', -- DisplayName - nvarchar(100)
          1, -- idMenu - int
          35000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'EGG COFFEE', -- DisplayName - nvarchar(100)
          1, -- idMenu - int
          30000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Dalgona Coffee', -- DisplayName - nvarchar(100)
          1, -- idMenu - int
          30000  -- price - float
          )

INSERT dbo.Drink
		( DisplayName, idMenu, price )
VALUES  ( N'Trà Đá', -- DisplayName - nvarchar(100)
          2, -- idMenu - int
          5000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà Xí Muội', -- DisplayName - nvarchar(100)
          2, -- idMenu - int
          10000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà Chanh', -- DisplayName - nvarchar(100)
          2, -- idMenu - int
          10000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà Tắc', -- DisplayName - nvarchar(100)
          2, -- idMenu - int
          5000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Orange Juice', -- DisplayName - nvarchar(100)
          3, -- idMenu - int
          15000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Lemon Juice', -- DisplayName - nvarchar(100)
          3, -- idMenu - int
          15000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Strawberry Juice', -- DisplayName - nvarchar(100)
          3, -- idMenu - int
          17000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Apple Juice', -- DisplayName - nvarchar(100)
          3, -- idMenu - int
          15000  -- price - float
          )
INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Watermelon Juice', -- DisplayName - nvarchar(100)
          3, -- idMenu - int
          15000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà sữa truyền thống', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          18000  -- price - float
          )
INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà sữa thái xanh', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          22000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà sữa matcha', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          22000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Sữa tươi trân châu đường đen', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          22000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trà sữa thái đỏ', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          22000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Trân châu thêm', -- DisplayName - nvarchar(100)
          4, -- idMenu - int
          2000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Coca', -- DisplayName - nvarchar(100)
          5, -- idMenu - int
          8000  -- price - float
          )

INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'7up', -- DisplayName - nvarchar(100)
          5, -- idMenu - int
          8000  -- price - float
          )
INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Pepsi', -- DisplayName - nvarchar(100)
          5, -- idMenu - int
          8000  -- price - float
          )
INSERT dbo.Drink
        ( DisplayName, idMenu, price )
VALUES  ( N'Nước Lọc', -- DisplayName - nvarchar(100)
          5, -- idMenu - int
          5000  -- price - float
          )

-- add bill
INSERT dbo.Bill
        ( DateCheckIn ,
          DateCheckOut ,
          idTable ,
          status
        )
VALUES  ( GETDATE() , -- DateCheckIn - datetime
          NULL , -- DateCheckOut - datetime
          1 , -- idTable - int
          0  -- status - int
        )

INSERT dbo.Bill
        ( DateCheckIn ,
          DateCheckOut ,
          idTable ,
          status
        )
VALUES  ( GETDATE() , -- DateCheckIn - datetime
          NULL , -- DateCheckOut - datetime
          2 , -- idTable - int
          0  -- status - int
        )

INSERT dbo.Bill
        ( DateCheckIn ,
          DateCheckOut ,
          idTable ,
          status
        )
VALUES  ( GETDATE() , -- DateCheckIn - datetime
          GETDATE(), -- DateCheckOut - datetime
          2 , -- idTable - int
          1  -- status - int
        )

INSERT dbo.Bill
        ( DateCheckIn ,
          DateCheckOut ,
          idTable ,
          status
        )
VALUES  ( GETDATE() , -- DateCheckIn - datetime
          GETDATE(), -- DateCheckOut - datetime
          3 , -- idTable - int
          1  -- status - int
        )

/*add BillList*/

INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 1, -- idBill - int
          1, -- idDrink - int
          2  -- count - int
          )
INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 3, -- idBill - int
          3, -- idDrink - int
          4  -- count - int
          )
INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 2, -- idBill - int
          5, -- idDrink - int
          2  -- count - int
          )
INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 4, -- idBill - int
          1, -- idDrink - int
          2  -- count - int
          )

INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 4, -- idBill - int
          5, -- idDrink - int
          3  -- count - int
          )

INSERT dbo.BillList
        ( idBill, idDrink, count )
VALUES  ( 1, -- idBill - int
          4, -- idDrink - int
          2  -- count - int
          )
GO

SELECT * FROM dbo.Bill WHERE idTable = 2 AND status = 0

SELECT D.DisplayName,BL.count, D.price, D.price* BL.count AS totalPrice FROM dbo.BillList AS BL, dbo.Bill AS B, dbo.Drink AS D 
WHERE BL.idBill = B.id AND BL.idDrink = D.id AND B.status = 0 AND B.idTable = 1

SELECT * FROM dbo.Bill

SELECT * FROM dbo.BillList

SELECT * FROM dbo.Drink

SELECT * FROM dbo.Menu

SELECT * FROM dbo.Tablee

Select * FROM Drink WHERE idMenu =1

CREATE PROC USP_InsertBill
@idTable INT
AS
BEGIN
	INSERT dbo.Bill
	        ( DateCheckIn ,
	          DateCheckOut ,
	          idTable ,
	          status
	        )
	VALUES  ( GETDATE() , -- DateCheckIn - datetime
	          Null , -- DateCheckOut - datetime
	          @idTable , -- idTable - int
	          0  -- status - int
	        )
END
GO

CREATE PROC USP_InsertBillList
@idBill INT, @idDrink INT, @count INT
AS
BEGIN
	DECLARE @isExitsBillList INT
	DECLARE @drinkcount INT = 1

	SELECT @isExitsBillList = id, @drinkcount = count FROM dbo.BillList WHERE idBill = @idBill AND idDrink = @idDrink

	IF(@isExitsBillList >0)
	BEGIN
	DECLARE @newCount INT = @drinkcount +@count
	IF(@newCount > 0)
		UPDATE dbo.BillList SET count = @drinkcount + @count WHERE idDrink = idDrink
	ELSE
		DELETE dbo.BillList WHERE idBill = @idBill AND idDrink = @idDrink
	END
	ELSE
	BEGIN
		INSERT dbo.BillList
				( idBill, idDrink, count )
		VALUES  ( @idBill, -- idBill - int
				  @idDrink, -- idDrink - int
				  @count  -- count - int
				  )
	END
END

SELECT MAX(id) FROM dbo.Bill
GO

CREATE TRIGGER UTG_UpdateBillList
ON dbo.BillList FOR INSERT, UPDATE
AS
BEGIN
	DECLARE @idBill INT
	
	SELECT @idBill = idBill FROM Inserted

	DECLARE @idTable INT

	SELECT @idTable = idTable FROM dbo.Bill WHERE id = @idBill AND status = 0

	UPDATE dbo.Tablee SET status = N'Position is been filled' WHERE id = @idTable
END
GO

DELETE dbo.BillList
DELETE dbo.Bill
GO


CREATE TRIGGER UTG_UpdateBill
ON dbo.Bill FOR UPDATE
AS
BEGIN
	DECLARE @idBill INT

	SELECT @idBill = id FROM Inserted

	DECLARE @idTable INT

	SELECT @idTable = idTable FROM dbo.Bill WHERE id = @idBill 

	DECLARE @count int = 0
	SELECT COUNT(*) FROM dbo.Bill WHERE id = @idTable
	
	IF (@count = 0)
		UPDATE dbo.Tablee SET status = N'Empty'
END
GO
 


	


 




















